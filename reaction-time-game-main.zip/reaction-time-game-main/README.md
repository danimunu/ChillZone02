# reaction-time-game
A simple game to measure reaction time 
