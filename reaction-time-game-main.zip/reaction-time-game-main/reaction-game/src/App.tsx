import React from 'react';
import logo from './logo.svg';
import './App.css';
// import ReactionTimeGame from './Game';
import ReactionGame from './ReactionGame';

function App() {
  return (
    <div className="App">
      <ReactionGame />
    </div>
  );
}

export default App;
